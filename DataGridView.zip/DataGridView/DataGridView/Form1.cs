using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;


namespace SubscribersApp
{
    public partial class Form1 : Form
    {
        List<Subscriber> subscribers = new List<Subscriber>();
        string filePath = "subscribers.json";

        public Form1()
        {
            InitializeComponent();
            LoadSubscribers();
        }

        void LoadSubscribers()
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                subscribers = JsonSerializer.Deserialize<List<Subscriber>>(json) ?? new List<Subscriber>();
            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = subscribers;
        }

        void SaveSubscribers()
        {
            string json = JsonSerializer.Serialize(subscribers, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            EditForm form = new EditForm();

            if (form.ShowDialog() == DialogResult.OK)
            {
                subscribers.Add(form.subscriber);
                SaveSubscribers();
                LoadSubscribers();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            int index = dataGridView1.CurrentRow.Index;

            EditForm form = new EditForm(subscribers[index]);

            if (form.ShowDialog() == DialogResult.OK)
            {
                subscribers[index] = form.subscriber;
                SaveSubscribers();
                LoadSubscribers();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}