﻿namespace SubscribersApp
{
    public class Subscriber
    {
        public string? Name { get; set; }
        public string? Phone { get; set; }
        public string? Address { get; set; }
    }
}