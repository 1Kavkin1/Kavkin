﻿using System;
using System.Windows.Forms;

namespace SubscribersApp
{
    public partial class EditForm : Form
    {
        public Subscriber subscriber = new Subscriber();

        public EditForm()
        {
            InitializeComponent();
        }

        public EditForm(Subscriber sub)
        {
            InitializeComponent();

            txtName.Text = sub.Name;
            txtPhone.Text = sub.Phone;
            txtAddress.Text = sub.Address;
        }
        private void EditForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            subscriber.Name = txtName.Text;
            subscriber.Phone = txtPhone.Text;
            subscriber.Address = txtAddress.Text;

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}