﻿namespace SubscribersApp
{
    partial class EditForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnSave;

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtPhone = new TextBox();
            txtAddress = new TextBox();
            btnSave = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Location = new Point(242, 60);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 39);
            txtName.TabIndex = 3;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(242, 118);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(150, 39);
            txtPhone.TabIndex = 4;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(242, 174);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(150, 39);
            txtAddress.TabIndex = 5;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(41, 274);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(170, 84);
            btnSave.TabIndex = 6;
            btnSave.Text = "Зберегти";
            btnSave.Click += btnSave_Click;
            // 
            // label1
            // 
            label1.Location = new Point(136, 63);
            label1.Name = "label1";
            label1.Size = new Size(100, 39);
            label1.TabIndex = 0;
            label1.Text = "Ім'я";
            // 
            // label2
            // 
            label2.Location = new Point(108, 118);
            label2.Name = "label2";
            label2.Size = new Size(128, 39);
            label2.TabIndex = 1;
            label2.Text = "Телефон";
            // 
            // label3
            // 
            label3.Location = new Point(120, 174);
            label3.Name = "label3";
            label3.Size = new Size(116, 39);
            label3.TabIndex = 2;
            label3.Text = "Адреса";
            // 
            // EditForm
            // 
            ClientSize = new Size(1119, 615);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(txtName);
            Controls.Add(txtPhone);
            Controls.Add(txtAddress);
            Controls.Add(btnSave);
            Name = "EditForm";
            Text = "Редагування";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}